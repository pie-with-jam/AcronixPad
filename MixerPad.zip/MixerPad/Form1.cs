﻿using System;
using System.IO;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace AcronixPad
{
    public partial class Form1 : Form
    {
        String open_path = "";

        public Form1()
        {
            InitializeComponent();
            comboBox1.SelectedIndex = 0;
        }

        private void comboBox1_SelectedIndexChanged_1(object sender, EventArgs e) { }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void открытьToolStripMenuItem_Click_1(object sender, EventArgs e)
        {
            if (openFileDialog1.ShowDialog() == DialogResult.Cancel)
                return;
            string filename2 = openFileDialog1.FileName;
            string text = File.ReadAllText(filename2);
            fastColoredTextBox1.Text = text;
            open_path = filename2;
            string path = File.ReadAllText("files/path.t$");
        }

        private void сохранитьToolStripMenuItem_Click(object sender, EventArgs e)
        {
            string path = File.ReadAllText("files/path.t$");
            File.WriteAllText(path, fastColoredTextBox1.Text);
        }

        private void сохранитьКакToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (comboBox1.Text == "TEXT (.TXT File)")
                saveFileDialog1.Filter = "Текстовый документ (*.txt)|*.txt";
            else if (comboBox1.Text == "CSharp")
                saveFileDialog1.Filter = "CSharp source file (*.cs)|*.cs";
            else if (comboBox1.Text == "Lua")
                saveFileDialog1.Filter = "Lua source file (*.lua)|*.lua";
            else if (comboBox1.Text == "HTML")
                saveFileDialog1.Filter = "HTML Web Page (*.html)|*.html";
            if (saveFileDialog1.ShowDialog() == DialogResult.Cancel)
                return;
            string filename = saveFileDialog1.FileName;
            File.WriteAllText(filename, fastColoredTextBox1.Text);
            File.WriteAllText("files/path.t$", filename);
        }

        private void шрифтToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (fastColoredTextBox1.TextLength > 0)
            {
                fastColoredTextBox1.SelectAll();
            }
        }

        private void шрифтToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            fontDialog1.ShowDialog();
            fastColoredTextBox1.Font = fontDialog1.Font;
        }

        private void вырезатьToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (fastColoredTextBox1.TextLength > 0)
            {
                fastColoredTextBox1.Cut();
            }
        }

        private void вставитьToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (fastColoredTextBox1.TextLength > 0)
            {
                fastColoredTextBox1.Paste();
            }
        }

        private void фToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (fastColoredTextBox1.TextLength > 0)
            {
                fastColoredTextBox1.Copy();
            }
        }

        private void фонToolStripMenuItem_Click(object sender, EventArgs e)
        {
            colorDialog1.ShowDialog();
            fastColoredTextBox1.BackColor = colorDialog1.Color;
        }

        private void справкаToolStripMenuItem_Click_1(object sender, EventArgs e)
        {
            info info = new info();
            info.Show();
        }

        private void fastColoredTextBox1_TextChanged(object sender, FastColoredTextBoxNS.TextChangedEventArgs e)
        {
            string text = fastColoredTextBox1.Text;
            string[] lines = text.Split('\n');
            label3.Text = "Символов: " + text.Length.ToString();
            label2.Text = "Строк: " + lines.Length.ToString();
            if (comboBox1.Text == "CSharp")
            {
                fastColoredTextBox1.Language = FastColoredTextBoxNS.Language.CSharp;
                autocompleteMenu1.Items = File.ReadAllLines("system/dicrs/cs-reserv-list.dicr");
            }
            else if (comboBox1.Text == "Lua")
            {
                fastColoredTextBox1.Language = FastColoredTextBoxNS.Language.Lua;
                autocompleteMenu1.Items = File.ReadAllLines("system/dicrs/lua-reserv-list.dicr");
            }
            else if (comboBox1.Text == "HTML")
            {
                if (fastColoredTextBox1.Text == "<!DOC")
                {
                    fastColoredTextBox1.Text = "<!DOCTYPE html>\n  <head>\n    <title>Your title</title>\n  </head>\n  <body>\n    <h1>Your text</h1>\n  </body>\n</html>";
                }
                fastColoredTextBox1.Language = FastColoredTextBoxNS.Language.HTML;
            }
            else if (comboBox1.Text == "TEXT (.TXT File)")
            {
                fastColoredTextBox1.Language = FastColoredTextBoxNS.Language.Custom;
                autocompleteMenu1.Items = null;
            }
        }
    }
}

